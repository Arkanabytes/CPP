/*5. Escriu un programa per trobar l'�ndex d'un element dins de d'una llista.
Utilitza la llista anterior i cerca l'�ndex de 2016 */
/*Alejandra Pinto*/
#include <iostream>
#include <list>
#include <string.h>
using namespace std;
int main (){

	
	int vector []={1789, 2035, 1899, 1456, 2013, 2016, 1458, 2458, 1254, 1472};
	int numeros,n;
	for (int i=0;i<n; i++){
		cout <<"Digite un numero: \n ";cin >>numeros [int];//guardo els elements del vector
	}
	//ara mostrare els elements con sus index asociats
	for (int i=0;1<n;i++){
		cout << i << numeros [i];
	}
	getch ();
	return 0;
}
